 function    [mImage] = mosaicImage(baseImage,tileImages,contrastScale) 
% function Get The base Image , 
% 4 Images as a matrix, Each Image is a row
% contrast scale which is multiple on the Base picture at the End
 a = size(tileImages);              %check Tile Size
 Image_Tile_Size = (a(2) ^ 0.5 );%check Tile Size
 Image_Tile_Number=a(1);        %check number of tiles
 b=size(baseImage);                  %check base image Size
 base_Image_size = b(1);        %check base image Size
 
 for i=1 :Image_Tile_Size : base_Image_size
    for j=1 : Image_Tile_Size : base_Image_size
   %move row by row
        Random_Tile=randomInt(1,1,Image_Tile_Number);   % selecting the Tile Image
        Image_Matrix_Mean = mean (mean (baseImage(j:j+Image_Tile_Size-1 ,i:i+Image_Tile_Size-1 )))   ;     %base Image Sector Mean                                                       %mean of the subMatrix
        Selected_Tile = tileImages (Random_Tile , 1:Image_Tile_Size*Image_Tile_Size);                                 % the Selected Image as a matrix
        Selected_Tile = Selected_Tile*contrastScale;                %change Contrast
        Diffrence_Between_Images = Image_Matrix_Mean  -  mean( Selected_Tile);                          %mean diffrences
        Image_Tile_Vector_Tmp = Selected_Tile+Diffrence_Between_Images;                                % Set the same Mean for the selected Image
        
        %plant the Tile Image in the Right Place at the Basic Image
        baseImage (j:j+Image_Tile_Size-1 ,i:i+Image_Tile_Size-1)  = reshape(Image_Tile_Vector_Tmp,Image_Tile_Size,Image_Tile_Size) ;
        
    end 
   
 end
baseImage(find(baseImage<0))=0;
baseImage(find(baseImage>256))=256;

mImage = baseImage ;     %returned Image