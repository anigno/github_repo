 function    [mImage] = mosaicImage(baseImage,tileImages,contrastScale) 
% function Get The base Image , 
% 4 Images as a matrix, Each Image is a row
% contrast scale which is multiple on the Base picture at the End
 Image_Size = 4;
 
 for i=1 :Image_Size : 256
    for j=1 : Image_Size : 256
   %move row by row
        Random_Tile=randomInt(1,1,4);   % selecting the Tile Image
        Image_Matrix_Mean = mean (mean (baseImage(j:j+Image_Size-1 ,i:i+Image_Size-1 )))   ;     %base Image Sector Mean                                                       %mean of the subMatrix
        Selected_Tile = tileImages (Random_Tile , 1:Image_Size*Image_Size);                                 % the Selected Image as a matrix
        Diffrence_Between_Images = Image_Matrix_Mean  -  mean( Selected_Tile);                          %mean diffrences
        Image_Tile_Vector_Tmp = Selected_Tile+Diffrence_Between_Images;                                % Set the same Mean for the selected Image
        
        %plant the Tile Image in the Right Place at the Basic Image
        baseImage (j:j+Image_Size-1 ,i:i+Image_Size-1)  = reshape(Image_Tile_Vector_Tmp,Image_Size,Image_Size) ;
        
    end 
   
 end


baseImage(find(BaseImage>256)=256);
mImage = baseImage *contrastScale;      %returned Image