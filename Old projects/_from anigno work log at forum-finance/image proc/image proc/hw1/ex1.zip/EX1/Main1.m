Image_Matrix = readimage('face.tif');                                                               %read Image
Image_Tile1 = readimage('boat.tif');                                                                   %Read Tile
Image_Tile2 = readimage('elephant.tif');  
Image_Tile3 = readimage('face2.tif');  
Image_Tile4 = readimage('smile.tif');  
Image_Size = 4;                                                                             %   Tile Image size

%Resize tile
Image_Tile1_Resize = resizeim ( Image_Tile1 , Image_Size , Image_Size );   
% tern the Tile in to a vector
Image_Tile1_Vector = reshape( Image_Tile1_Resize , 1 , Image_Size*Image_Size )  ;     

Image_Tile2_Resize = resizeim ( Image_Tile2 , Image_Size , Image_Size );                                                                                
Image_Tile2_Vector = reshape( Image_Tile2_Resize , 1 , Image_Size*Image_Size )   ; 

Image_Tile3_Resize = resizeim ( Image_Tile3 , Image_Size , Image_Size ) ;                                                                                
Image_Tile3_Vector = reshape( Image_Tile3_Resize , 1 , Image_Size*Image_Size )   ; 

Image_Tile4_Resize = resizeim ( Image_Tile4 , Image_Size , Image_Size );                                                                                
Image_Tile4_Vector = reshape( Image_Tile4_Resize , 1 , Image_Size*Image_Size )  ; 

%images tile into matrix each row is a tile
Images_Tile_Matrix = [Image_Tile1_Vector ; Image_Tile2_Vector ;Image_Tile3_Vector ; Image_Tile4_Vector];            



showimage( mosaicImage( Image_Matrix , Images_Tile_Matrix , 0.95 ) );



