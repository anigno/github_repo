Image_Matrix = readimage('fruit.tif');                                                                                                          %read Image
Image_Tile1 = readimage('boat.tif');                                                                                                                %Read Tile
Image_Size = 4;
Image_Tile1_Resize = resizeim (Image_Tile1,Image_Size,Image_Size);                                                                                %Resize tile
Image_Tile1_Vector = reshape(Image_Tile1_Resize,1,Image_Size*Image_Size)                                                                   % tern the Tile in to a vector


for i=1 :Image_Size : 256
    for j=1 : Image_Size : 256
        
        Image_Matrix_Mean = mean (mean (Image_Matrix(j:j+Image_Size-1 ,i:i+Image_Size-1 )))     ;                                                           %mean of the subMatrix
        Diffrence_Between_Images = Image_Matrix_Mean  -  mean(Image_Tile1_Vector);                  %mean diffrences
        Image_Tile1_Vector_Tmp = Image_Tile1_Vector+Diffrence_Between_Images;                                                                                     % Gat the same Mean

        Image_Matrix (j:j+Image_Size-1 ,i:i+Image_Size-1)  = reshape(Image_Tile1_Vector_Tmp,Image_Size,Image_Size) ;
        
    end 
end
Image_Matrix = Image_Matrix*0.8;
showimage(Image_Matrix)


