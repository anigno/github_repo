function    ret = var2 (v1,v2,m1,m2)


m12 = (m1+m2)/2;
v12 = (v1+v2+m1^2+m2^2)/2 - m12^2;

ret =v12;

