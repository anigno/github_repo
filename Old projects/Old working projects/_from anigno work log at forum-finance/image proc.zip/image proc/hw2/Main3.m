im = readImage('lena100_SandP.tif');
showimage(im);


showimage(blur(im,0.5));