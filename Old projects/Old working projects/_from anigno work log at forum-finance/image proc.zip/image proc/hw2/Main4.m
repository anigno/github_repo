im = readImage('lena100.tif');

showimage(im)

showimage(sharpen(im,0.8));




