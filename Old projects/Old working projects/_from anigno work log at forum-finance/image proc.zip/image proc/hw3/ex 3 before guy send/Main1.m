k = 5;
Bsize = 11;

FBasis1d(k)
     
     
        
        
    
    