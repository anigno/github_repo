kx= 5;
ky = 7;
FBasis2d(kx,ky)