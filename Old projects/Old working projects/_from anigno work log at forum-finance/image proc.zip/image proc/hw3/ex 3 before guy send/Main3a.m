
vSpaceDim = [ 11 11];
basisFunc = 'FBasis2d';
Result = testOrtho2d(basisFunc,vSpaceDim)