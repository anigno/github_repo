function mmr(x);

[ min(x(:)) max(x(:))]
