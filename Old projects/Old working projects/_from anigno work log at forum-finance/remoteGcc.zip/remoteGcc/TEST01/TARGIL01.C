#include<stdio.h>
int main(){
float dNumber,dSum=0;
	int a;
	printf("enter 5 numbers\n");
	for(a=0;a<5;a++){
	scanf("%e",&dNumber);
		dSum+=dNumber;
	}//for
	printf("\n%e\n",dSum);
return 0;
}//main()
