Option Strict Off
Option Explicit On
Module mdlMain
	Public selectDirReturnValue As String
	Public currentFile As String
	Public ftpHost As String
	Public ftpUsername As String
	Public ftpPassword As String
	Public TelnetNumber As Object
End Module