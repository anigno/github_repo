#include<iostream.h>


void main(){



}