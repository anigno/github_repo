package controls.calendar;

import utilClasses.aDate;

public interface calendarDateSelectionListener {
    void calendarDateSelectioMade(aDate date);
}
