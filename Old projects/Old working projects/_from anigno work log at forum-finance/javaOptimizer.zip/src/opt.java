
import gui.tGui;

public class opt {
    public static void main(String args[]){
        new tGui();
    }//main
}//class opt
