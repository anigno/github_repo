public class Ex3Prog {
    public static void main(String args[]){
        //the only cMdiFrame
        cMdiFrame mdiFrame=new cMdiFrame();
    }//main
}//class Ex3Prog
