public class cMain {
    public static void main(String args[]){
        new cEditor();

    }//main()
}//class cMain
