package anignoControls;

public interface dragListener {
    public void dragEnd(Object obj);
    public void dragStart(Object obj);
}
