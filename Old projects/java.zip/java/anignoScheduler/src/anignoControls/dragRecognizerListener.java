package anignoControls;

/**
 * Created by IntelliJ IDEA.
 * User: anigno
 * Date: 27/04/2005
 * Time: 10:37:28
 * To change this template use File | Settings | File Templates.
 */
public interface dragRecognizerListener {
}
