package _testCustomEvents;

public interface MoodListener 
{
    public void moodReceived( MoodEvent event );
}

