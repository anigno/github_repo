package customEvents;

import customEvents.textButtonTextChangedEvent;

/**
 * listener interface for the textButtonTextChangedEvent 
 */
public interface textButtonTextChangedListener {
    public void textButtonTextChanged(textButtonTextChangedEvent event );
}
