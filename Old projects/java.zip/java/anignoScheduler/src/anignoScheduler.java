
import gui.mainFrame;

public class anignoScheduler {
    public static void main(String args[]){
        mainFrame m=new mainFrame("anigno Scheduler");   
    }
}
