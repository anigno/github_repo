public class class_math {
    public static final double PI=3.1415;
    Integer i=new Integer(20);  //WRAPPER class
    


}
