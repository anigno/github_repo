public class class_main {
    public static void main(String args[]){

    }//main
}
