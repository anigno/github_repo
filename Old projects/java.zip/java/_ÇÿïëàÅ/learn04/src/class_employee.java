public class class_employee {
    class_myDate birthDay=new class_myDate();
    class_myDate startWorking=new class_myDate();
    String name;
    float salary;

}
