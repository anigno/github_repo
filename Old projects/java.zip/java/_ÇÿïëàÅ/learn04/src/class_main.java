import java.util.*;

public class class_main {
    public static void main(String args[]){
        class_employee employee;
        employee = new class_employee();
        employee.birthDay.set(16,12,1971);  //message sending to object
        //Encapsulation (information hiding)
        //employee.startWorking.day=21;     //day has private access

        class_myDate d1=new class_myDate(23,7,2006);
        class_myDate d2=new class_myDate();

        //STANDARD LIBRAY
        Date now=new Date();
        System.out.println(now);


    }
}
