public class class_myDate {
    private int day;
    private int month;
    private int year=2000;

    public void set(int d,int m,int y){
        day=d;
        month=m;
        year=y;
    }//set

    //constructors
    class_myDate(int d,int m,int y){
        day=d;month=m;year=y;
    }
    class_myDate(){        
    }
}//class_myDate
