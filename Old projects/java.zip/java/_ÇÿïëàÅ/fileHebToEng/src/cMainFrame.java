import javax.swing.*;
import java.io.File;

public class cMainFrame extends JFrame{
    JFileChooser fc;
    cList fileList;

    cMainFrame(){
        //setup frame
        super("File heb to eng");
        getContentPane().setLayout(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(640,480);
        setVisible(true);
        //setup fileList
        fileList=new cList(getContentPane(),0,0,300,400);
        //setup fileChooser
        fc=new JFileChooser("c:");
        fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fc.setMultiSelectionEnabled(true);
        int ret=fc.showOpenDialog(this);
        if(ret==JFileChooser.APPROVE_OPTION){
            File files[]=fc.getSelectedFiles();
            for(int a=0;a<files.length;a++){
                File fOld=files[a];
                StringBuffer newName=new StringBuffer(fOld.toString());
                fileList.model.addElement(newName);
                for(int b=0;b<newName.length();b++){
                    switch(newName.charAt(b)){
                        case '�':
                            newName.setCharAt(b,'a');
                            break;
                        case '�':
                            newName.setCharAt(b,'b');
                            break;
                        case '�':
                            newName.setCharAt(b,'g');
                            break;
                        case '�':
                            newName.setCharAt(b,'d');
                            break;
                        case '�':
                            newName.setCharAt(b,'h');
                            break;
                        case '�':
                            newName.setCharAt(b,'v');
                            break;
                        case '�':
                            newName.setCharAt(b,'z');
                            break;
                        case '�':
                            newName.setCharAt(b,'H');
                            break;
                        case '�':
                            newName.setCharAt(b,'t');
                            break;
                        case '�':
                            newName.setCharAt(b,'i');
                            break;
                        case '�':
                            newName.setCharAt(b,'c');
                            break;
                        case '�':
                            newName.setCharAt(b,'c');
                            break;
                        case '�':
                            newName.setCharAt(b,'l');
                            break;
                        case '�':
                            newName.setCharAt(b,'m');
                            break;
                        case '�':
                            newName.setCharAt(b,'m');
                            break;
                        case '�':
                            newName.setCharAt(b,'n');
                            break;
                        case '�':
                            newName.setCharAt(b,'n');
                            break;
                        case '�':
                            newName.setCharAt(b,'s');
                            break;
                        case '�':
                            newName.setCharAt(b,'A');
                            break;
                        case '�':
                            newName.setCharAt(b,'p');
                            break;
                        case '�':
                            newName.setCharAt(b,'p');
                            break;
                        case '�':
                            newName.setCharAt(b,'Z');
                            break;
                        case '�':
                            newName.setCharAt(b,'Z');
                            break;
                        case '�':
                            newName.setCharAt(b,'k');
                            break;
                        case '�':
                            newName.setCharAt(b,'r');
                            break;
                        case '�':
                            newName.setCharAt(b,'S');
                            break;
                        case '�':
                            newName.setCharAt(b,'T');
                            break;
                    }//switch
                }//for
                fOld.renameTo(new File(newName.toString()));
            }//for


        }//if

    }//cMainFrame()
}//class cMainFrame
