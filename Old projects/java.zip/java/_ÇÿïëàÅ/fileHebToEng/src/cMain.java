public class cMain {
    public static void main(String args[]){
        new cMainFrame();
    }//main()
}//class cMain
