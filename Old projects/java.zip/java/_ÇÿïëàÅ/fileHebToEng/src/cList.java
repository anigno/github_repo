import javax.swing.*;
import java.awt.*;

public class cList{
    DefaultListModel model=new DefaultListModel();
    JList list=new JList(model);
    JScrollPane scrollPane=new JScrollPane(list);

    cList(Container container,int X,int Y,int width,int height){
        container.add(scrollPane);
        scrollPane.setBounds(X,Y,width,height);
        scrollPane.setVisible(true);
    }//cList()

}//class cList
