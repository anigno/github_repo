public class cGetMoney extends Thread{
    public void run(){
        for(int a=0;a<100;a++){
            
        }//for
    }//run
}//class
