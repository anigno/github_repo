public class cPutMoney implements Runnable{
    public void run() {
        for(int a=0;a<100;a++){
            cMain.money++;
        }//for
    }//run
}//class
