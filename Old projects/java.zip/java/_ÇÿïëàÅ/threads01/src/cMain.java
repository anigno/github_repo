public class cMain {
    static int money=0;
    public static void main(String args[]){

         }//main
}//class cMain
