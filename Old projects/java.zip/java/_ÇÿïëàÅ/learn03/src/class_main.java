public class class_main {
    public static void main(String args[]){
            for(int a=0;a<=9;a++){
                System.out.println("");
                for(int b=9;b>=0;b--){
                    if(b==a)break;
                    System.out.print(" "+a+"-"+b+";");
                }
            }
        }//main()
}
