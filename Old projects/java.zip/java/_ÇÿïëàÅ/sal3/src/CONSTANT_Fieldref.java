import java.io.DataInputStream;
import java.io.IOException;

public class CONSTANT_Fieldref extends BasicClass
{
	private short class_index;
	private short name_and_type_index;
		
	CONSTANT_Fieldref(DataInputStream input,int constantNum) throws IOException
	{
		tag = 9;	
		constIndex = constantNum;	
		class_index = input.readShort();	//class_index
		name_and_type_index = input.readShort();	//name_and_type_index
		
		constantNum--;	// for undouble cnting
		
		for (; constantNum >= 0; constantNum-- )
	    {
		    if (GlobalVec.vec[constantNum].getTag() == tag)
		    {	
			    if (((CONSTANT_Fieldref)GlobalVec.vec[constantNum]).GetClassIndex() == 
			    	class_index)
			    {
			  	  if (((CONSTANT_Fieldref)GlobalVec.vec[constantNum]).getNameAndTypeIndex() ==
			  	  	 name_and_type_index)	
					  throw new IOException("Invalid Input");
			    }			  
		    }		
		}	
		  
		if (GlobalVec.vec[class_index].getTag() != 7)	//CLASS tag
			throw new IOException("Multiple Declaration");
			
		if ((GlobalVec.vec[name_and_type_index].getTag() != 12))//	NAMEANDTYPE tag
			throw new IOException("Multiple Declaration");
	}
	
/*****/

	public String print()
	{
		return("Constant Type: FIELDREF\ntag: "+tag+"\nClass Index:"+class_index+
		"\nName And Type Index: "+name_and_type_index+"\nClass String: "+
			(GlobalVec.vec[class_index]).getName()+"\nName And Type String: "+(GlobalVec.vec[name_and_type_index]).getName());
 	}

	public String toString() { return("["+constIndex+"]"+getName());}
	public short GetClassIndex() { return class_index; }
	public short getNameAndTypeIndex() { return name_and_type_index; }

	public int getTag() { return tag; }
	public String getName()
	{
	 	 return (GlobalVec.vec[class_index]).getName()+"."
		+(GlobalVec.vec[name_and_type_index]).getName(); 
	}
}







