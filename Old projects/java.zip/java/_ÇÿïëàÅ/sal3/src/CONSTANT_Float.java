import java.io.DataInputStream;
import java.io.IOException;

public class CONSTANT_Float extends BasicClass
{
	private float bytes;
	
	CONSTANT_Float(DataInputStream input,int constantNum) throws IOException
	{
		tag = 4;
		bytes = input.readFloat();
		constIndex = constantNum;
		constantNum--;	

		for (; constantNum >= 0; constantNum-- )
		{
			if (GlobalVec.vec[constantNum].getTag() == tag)
			{	
				if (((CONSTANT_Float)GlobalVec.vec[constantNum]).getBytes() == bytes)
					throw new IOException("Invalid Input");
			}			
		}
	}
	
/*****/
	
	public String print()
	{
		return("Constant Type: FLOAT\ntag: "+tag+"\nFloat Value:"+bytes);
	}

	public String toString() { return("["+constIndex+"]"+bytes);	}
    public String getName() { return (""+bytes); }
	public int getTag() { return tag; }
	private float getBytes() { return bytes; } 
}
