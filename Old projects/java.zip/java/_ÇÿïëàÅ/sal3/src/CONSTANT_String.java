import java.io.DataInputStream;
import java.io.IOException;

public class CONSTANT_String extends BasicClass
{
	private short string_index;	//the "name" of the object
	
	CONSTANT_String(DataInputStream input,int constantNum) throws IOException
	{
		tag = 8;
		string_index = input.readShort();	//reading 
		constIndex = constantNum;
		constantNum--;	

		for (; constantNum >= 0; constantNum-- )
		{
			if (GlobalVec.vec[constantNum].getTag() == tag)
			{	
				if (((CONSTANT_String)GlobalVec.vec[constantNum]).getStringIndex() 
					== string_index)
					throw new IOException("Invalid Input");
			}		
		}
		if ((GlobalVec.vec[string_index]).getTag()!= 1)	//if not pointing to UTF8 - Illegal!
		{
			throw new IOException("Invalid Input");
		}
		
	}
	
/*****/

  	public String print()
  	{
		return("Constant Type: STRING\ntag: "+tag+"\nString Index:"+string_index+"\nString:"+getName());
    }	

	public String toString() { return("["+constIndex+"]"+getName()); }
	public int getTag() { return tag; }	
	public short getStringIndex() { return string_index; }	
	public String getName() { return (GlobalVec.vec[string_index]).getName(); }
}
