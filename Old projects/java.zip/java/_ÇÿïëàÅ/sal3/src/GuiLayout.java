import java.awt.*;

//This file contains the Layout manager

class GuiLayout implements LayoutManager
 {

	public GuiLayout() { }

	public void addLayoutComponent(String name, Component comp) { }
	public void removeLayoutComponent(Component comp) {}

/****/

	public Dimension preferredLayoutSize(Container head) 
	{
		Dimension dim = new Dimension(0, 0);

		Insets insets = head.getInsets();
		dim.width = 700 + insets.left + insets.right;
		dim.height = 400 + insets.top + insets.bottom;

		return dim;
	}

/****/

	public Dimension minimumLayoutSize(Container head) 
	{
		Dimension dim = new Dimension(0, 0);
		return dim;
	}

/****/
	public void layoutContainer(Container head)
	 {
		Insets insets = head.getInsets();
		
		Component c;
		
		c = head.getComponent(0); //Constant_List
		if (c.isVisible()) 
		{
			c.setBounds(insets.left+24,insets.top+15,270,35);
		}
		
		c = head.getComponent(2); //Constant_List
		if (c.isVisible()) 
		{
			c.setBounds(insets.left+24,insets.top+55,270,330);
		}
		
		c = head.getComponent(1); //InfoWindow
		if (c.isVisible()) 
		{
			c.setBounds(insets.left+310,insets.top+55,350,330);
		}
	}
}