import java.io.DataInputStream;
import java.io.IOException;

public class SuperClassData extends BasicNode
{
	private short Super_index;	
		
	SuperClassData(DataInputStream data) throws IOException
	{
		Super_index = data.readShort();
		
		if ((GlobalVec.vec[Super_index]).getTag() != 7)	
			throw new IOException("Invalid Input");
	}

/****/
	
	public String print() 
	{		
		return ("Super Class Index: "+Super_index+"\nSuper Class Name: "+
		(GlobalVec.vec[Super_index]).getName());
	}
	
	public String toString() { return "Super Class"; }
}