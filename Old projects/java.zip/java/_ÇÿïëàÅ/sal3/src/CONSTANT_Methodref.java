import java.io.DataInputStream;
import java.io.IOException;

public class CONSTANT_Methodref extends BasicClass
{
	private short class_index;
	private short name_and_type_index;
		
	CONSTANT_Methodref(DataInputStream input,int constantNum) throws IOException
	{
		tag = 10;	
		constIndex = constantNum;	//Get index in the CP vector
		class_index = input.readShort();	//read next 2 bytes - for class_index
		name_and_type_index = input.readShort();//read next 2 bytes - for name_and_type_index
		
		constantNum--;	

		for (; constantNum >= 0; constantNum-- )
		  {
			  if (GlobalVec.vec[constantNum].getTag() == tag)
			  {	
				  if (((CONSTANT_Methodref)GlobalVec.vec[constantNum]).getClassIndex() == class_index) //same class found
				  {
					if (((CONSTANT_Methodref)GlobalVec.vec[constantNum]).getNameAndTypeIndex() == name_and_type_index)	//same name&type found
						throw new IOException("Invalid Input");//then error
				  }			  
			  }		
		  }		//end of while
		  
		  //Check legality of the FIELDREF structure
		if (GlobalVec.vec[class_index].getTag()!= 7)	//CLASS tag
			throw new IOException("Double Declaration");//then error
			
		if ((GlobalVec.vec[name_and_type_index].getTag()!= 12))//	NAMEANDTYPE tag
			throw new IOException("Double Declaration");//then error
	}
	
/*****/

	public String print()
	{
		return("Constant Type: METHODREF\ntag: "+tag+"\nClass Index:"+class_index+"\nName And Type Index: "+name_and_type_index+"\nClass String: "+(GlobalVec.vec[class_index]).getName()+"\nName And Type String: "+(GlobalVec.vec[name_and_type_index]).getName());
	}
 
	public String toString() { return("["+constIndex+"]"+getName()); }
    public short getClassIndex() { return class_index; }
	public short getNameAndTypeIndex() { return name_and_type_index; }
	public int getTag() { return tag; }
	public String getName()
	{
		 return (GlobalVec.vec[class_index]).getName()+"."+(GlobalVec.vec[name_and_type_index]).getName();
	}
}
