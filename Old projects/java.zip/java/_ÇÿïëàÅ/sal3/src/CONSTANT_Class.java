import java.io.DataInputStream;
import java.io.IOException;

public class CONSTANT_Class extends BasicClass
{
	private short name_index;	
	
	CONSTANT_Class() { } 
	
	CONSTANT_Class(DataInputStream input,int constantNum) throws IOException
	{
		tag = 7;
		name_index = input.readShort();	
		constIndex = constantNum;
		constantNum--;	// for undouble cnting
		
		for (; constantNum >= 0; constantNum-- )
		{
			if (GlobalVec.vec[constantNum].getTag() == tag)
			{	
				if (((CONSTANT_Class)GlobalVec.vec[constantNum]).getNameIndex() == name_index)
					throw new IOException("Invalid Input");
			}						
		}
		
		if ((GlobalVec.vec[name_index]).getTag() != 1)	//UTF8 
			throw new IOException("Invalid Input");		
	}
	
/****/

    public String print() 
    {
	   return("Constant Type: CLASS\ntag: "+tag+"\nName Index:"+name_index+"\n Class Name:"
	   	+getName());
    }	
  
	public String toString() { return("["+constIndex+"]"+getName());	}
	public int getTag() { return tag; }	
	public short getNameIndex() { return name_index; }	
	public String getName() { return (GlobalVec.vec[name_index]).getName(); }
}
