import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;

public class MyTreeModelListener implements TreeModelListener
{

	public void treeNodesChanged(TreeModelEvent arg0) { }
	public void treeNodesInserted(TreeModelEvent arg0) { }
	public void treeNodesRemoved(TreeModelEvent arg0) { }
	public void treeStructureChanged(TreeModelEvent arg0) { }
}


