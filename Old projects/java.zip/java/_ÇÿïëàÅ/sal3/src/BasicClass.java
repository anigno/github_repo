

abstract public class BasicClass extends BasicNode
{
	protected int tag;	//CONSTANT type
	protected int constIndex;
	
	abstract public String getName();
	abstract public int getTag();	
}
