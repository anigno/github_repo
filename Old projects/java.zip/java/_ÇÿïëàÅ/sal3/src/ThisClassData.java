import java.io.DataInputStream;
import java.io.IOException;

public class ThisClassData extends BasicNode
{
	private short this_index;	
		
	ThisClassData(DataInputStream data) throws IOException
	{
		this_index = data.readShort();
		if ((GlobalVec.vec[this_index]).getTag() != 7)	
			throw new IOException("Invalid Input");
	}

/****/
	
	public String print() 
	{
		
		return ("This Class Index: "+this_index+"\nThis Class Name: "+
		(GlobalVec.vec[this_index]).getName());
	}
	
	
	public String toString()
	{
		return "This Class";
	}
}