import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ClassFileData
{
	private MagicNumber myMagicClass;
	private Version myVersions;
	private ThisClassData myThisClass;
	private SuperClassData mySuperClass;
	private GlobalVec constantVec;	
	private FileInputStream filePtr;	
	private DataInputStream dataStream;	// for flows
	
	ClassFileData(File fileToOpen) throws FileNotFoundException
	{
		short tmp;
		
		filePtr = new FileInputStream(fileToOpen);
		dataStream = new DataInputStream(filePtr);
		
		try 
		{
			myMagicClass = new MagicNumber(dataStream);
			myVersions =  new Version(dataStream);
			constantVec = new GlobalVec(dataStream);	
			tmp = dataStream.readShort();	//access_flags
			myThisClass = new ThisClassData(dataStream);
			mySuperClass = new SuperClassData(dataStream);					
		}
		
		catch (IOException e) 
		{
			throw new FileNotFoundException("No File Found");
		}
	}

/****/
	
	public MagicNumber getMagic() { return myMagicClass; }	
	public Version getVersion() { return myVersions; }	
	public ThisClassData getThisClass() { return myThisClass; }
	public SuperClassData getSuperClass() {	return mySuperClass; }
}
