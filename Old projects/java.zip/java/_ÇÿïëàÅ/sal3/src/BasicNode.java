abstract public class BasicNode
{
	abstract public String print();
}
