import java.io.DataInputStream;
import java.io.IOException;

public class CONSTANT_Double extends BasicClass
{
	private double bytes;
	
	CONSTANT_Double(DataInputStream input,int constantNum) throws IOException
	{
		tag = 6;
		bytes = input.readDouble();
		constIndex = constantNum;
		constantNum--;	// for undouble cnting
		
		for (; constantNum >= 0; constantNum-- )
		{
			if (GlobalVec.vec[constantNum].getTag() == tag)
			{	
				if (((CONSTANT_Double)GlobalVec.vec[constantNum]).getBytes() == bytes)
					throw new IOException("Invalid Input");
			}			
		}
	}
	
/*****/
		
	private double getBytes()
	{
		return bytes;		
	}

	public String print()
	{
		return("Constant Type: DOUBLE\ntag: "+tag+"\nDouble Value:"+bytes);
	}

	public String toString() { return("["+constIndex+"]"+bytes); }
	public int getTag() { return tag; }
	public String getName() { return (""+bytes); }
}
