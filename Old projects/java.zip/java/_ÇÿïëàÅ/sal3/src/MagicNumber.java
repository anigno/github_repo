import java.io.DataInputStream;
import java.io.IOException;

public class MagicNumber extends BasicNode
{
	//4 Bytes
	private byte[] MagicNumberToCmp = {(byte)0xCA,(byte)0xFE,(byte)0xBA,(byte)0xBE};

	MagicNumber(DataInputStream dataStream) throws IOException
	{
		byte tempNum;
		
		// compare the magic num in the file to the one in the data structure
		for (int i = 0; i<4; i++)
		{
			tempNum = dataStream.readByte();
			if (tempNum != MagicNumberToCmp[i])
				throw new IOException("This is not a .class file ");
		} 
	}

/****/		

	public String print() { return("Magic: 0xCAFEBABE"); }	
	public String toString() { return("Magic"); }
}
