import java.awt.*;
import java.applet.Applet;
import java.io.File;
import java.io.FileNotFoundException;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

//This file contains the applet itself

public class GlobalGui extends Applet
{
	private JTextArea infoField;
	private JTree tmpTree;
	private DefaultMutableTreeNode head;
	private JScrollPane treeView;
	private JScrollPane tmpScrollPane;
	private TreeListener tmpTreeListener;
	private JComponent tmpComponent;
	private GuiFrame tmpFrame;
	private DefaultTreeModel treeHead;
	static private ClassFileData classFileInfo;

/*****/

	public void init()
	{
		tmpFrame = new GuiFrame("Class Viewer");
		JFrame.setDefaultLookAndFeelDecorated(true);
		tmpComponent = new FileChoose(this);
		tmpComponent.setOpaque(true);

		GuiLayout MyLayout  =  new GuiLayout();
		setFont(new Font("Arial", Font.PLAIN, 12));
		setLayout(MyLayout);
		add(tmpComponent);

		tmpTree = new JTree(treeHead);
		treeView = new JScrollPane(tmpTree);
		infoField = new JTextArea("Please open a .CLASS File");
		tmpScrollPane = new JScrollPane(infoField);
		tmpTreeListener = new TreeListener(tmpTree,infoField);
		tmpTree.addTreeSelectionListener(tmpTreeListener);
		add(tmpScrollPane);
		add(treeView);	//adding the scrollpane
		setSize(getPreferredSize());
		tmpFrame.add("Center", this);
		tmpFrame.pack();
		//Causes this Window to be sized to fit the preferred size and layouts of its subcomponents
		tmpFrame.setVisible(true);
	}

/*****/
	 public void createNewFilePresentation(File FileToRead)
	 {
		try
		{
			classFileInfo = new ClassFileData(FileToRead);
			head = new DefaultMutableTreeNode(FileToRead.getName());
			createTreeNodes();
			treeHead = new DefaultTreeModel(head);
			tmpTree.setModel(treeHead);
			infoField.setText("");
			tmpFrame.setTitle(FileToRead.getName());
		}
		 catch (FileNotFoundException e)
		 {
			infoField.setText("");
			infoField.insert("Please open a .class file",0);
		}
	 }

/*****/

	public void createTreeLeaves(DefaultMutableTreeNode folderName)
	{
		BasicClass tmpNode;
		DefaultMutableTreeNode nodeConst;

		int i;

		for (i = 0; i<GlobalVec.constPoolCnt; i++)
		{
			tmpNode = GlobalVec.vec[i];
			nodeConst = new DefaultMutableTreeNode(tmpNode);
			folderName.add(nodeConst);
		}
	}

/*****/

  private void createTreeNodes()
  {
	  	DefaultMutableTreeNode tmp;

		tmp = new DefaultMutableTreeNode(classFileInfo.getMagic());
	  	head.add(tmp);

		tmp = new DefaultMutableTreeNode(classFileInfo.getVersion());
		head.add(tmp);

		tmp = new DefaultMutableTreeNode(classFileInfo.getThisClass());
		head.add(tmp);

		tmp = new DefaultMutableTreeNode(classFileInfo.getSuperClass());
		head.add(tmp);

		tmp = new DefaultMutableTreeNode("Constant Pool");
		createTreeLeaves(tmp);
		head.add(tmp);
   }

/*****/

	public static void main(String args[]) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException
	{
		GlobalGui MyGui = new GlobalGui();
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		MyGui.init();
	}
}


