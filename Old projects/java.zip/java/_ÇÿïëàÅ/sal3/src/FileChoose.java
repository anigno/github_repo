import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class FileChoose extends JPanel implements ActionListener
{
	static private final String newline  =  "\n";
	private JButton openButton;
	private JTextArea log;
	private JFileChooser fc;
	private GlobalGui myGuiHandler;
	
	public FileChoose(GlobalGui myGui) 
	{
		super(new BorderLayout());
		
		myGuiHandler = myGui;		
		log  =  new JTextArea(5,20);
		log.setMargin(new Insets(5,5,5,5));
		log.setEditable(false);
		JScrollPane logScrollPane  =  new JScrollPane(log);

		//Create a file chooser
		fc  =  new JFileChooser();

		openButton  =  new JButton("To open a .CLASS file");
		openButton.addActionListener(this);

		JPanel buttonPanel  =  new JPanel(); //use FlowLayout
		buttonPanel.add(openButton);
		add(buttonPanel, BorderLayout.PAGE_START);
		add(logScrollPane, BorderLayout.CENTER);
	}
	
/*****/

	public void actionPerformed(ActionEvent e) 
	{
		//Handle open button action.
		if (e.getSource() == openButton) 
		{
			int returnVal = fc.showOpenDialog(FileChoose.this);

			if (returnVal  ==  JFileChooser.APPROVE_OPTION) {
				myGuiHandler.createNewFilePresentation(fc.getSelectedFile());	//Creating a new tree
				//This is where a real application would open the file.
				log.append("Opening: " + fc.getSelectedFile().getName() + "." + newline);
			} else {
				log.append("cancelled " + newline);
			}
			log.setCaretPosition(log.getDocument().getLength());
		}		
	}
}
