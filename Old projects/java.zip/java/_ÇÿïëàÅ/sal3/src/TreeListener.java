import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

public class TreeListener implements TreeSelectionListener
{
	private JTree thisTree;
	private JTextArea infoArea;
	
	// copy the tree
	TreeListener(JTree tmpTree, JTextArea tmpInfoArea)
	{
		thisTree = tmpTree;
		infoArea = tmpInfoArea;	
	}

/*****/
	
	public void valueChanged(TreeSelectionEvent event) 
	{
		DefaultMutableTreeNode tmpNode = (DefaultMutableTreeNode)thisTree.getLastSelectedPathComponent();
		BasicNode myType;
		
		if (tmpNode == null) 
			return;
			
		if (tmpNode.isLeaf() == false)
			return;
			 
		myType = (BasicNode)tmpNode.getUserObject();
		
		infoArea.setText("");
		infoArea.insert(myType.print(),0);
	}

	
} 