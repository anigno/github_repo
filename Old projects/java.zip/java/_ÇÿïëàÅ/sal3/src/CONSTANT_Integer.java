import java.io.DataInputStream;
import java.io.IOException;

public class CONSTANT_Integer extends BasicClass
{
	private int bytes;
	
	CONSTANT_Integer(DataInputStream input,int constantNum) throws IOException
	{
		tag = 3;
		bytes = input.readInt();
		constIndex = constantNum;
		constantNum--;	

		for (; constantNum >= 0; constantNum-- )
		{
			if (GlobalVec.vec[constantNum].getTag() == tag)
			{	
				if (((CONSTANT_Integer)GlobalVec.vec[constantNum]).getBytes() == bytes)
					throw new IOException("Invalid Input");
			}		
		}
	}
	
/*****/
	
	public String print()
	{
		return("Constant Type: Integer\ntag: "+tag+"\nInteger Value:"+bytes);
	}
	
	public String toString() { return("["+constIndex+"]"+bytes);	}
	public String getName() { return (""+bytes); }
	public int getTag() { return tag; }
	private int getBytes() { return bytes; }
}
