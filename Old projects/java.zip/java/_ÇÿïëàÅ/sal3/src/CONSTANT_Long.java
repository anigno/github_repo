import java.io.DataInputStream;
import java.io.IOException;

public class CONSTANT_Long extends BasicClass
{
	private long bytes;
	
	CONSTANT_Long(DataInputStream input,int constantNum) throws IOException
	{
		tag = 5;
		bytes = input.readLong();
		constIndex = constantNum;
		constantNum--;	

		for (; constantNum >= 0; constantNum-- )
		{
			if (GlobalVec.vec[constantNum].getTag() == tag)
			{	
				if (((CONSTANT_Long)GlobalVec.vec[constantNum]).getBytes() == bytes)
					throw new IOException("Invalid Input");
			}			
		}
	}	

/*****/

	private long getBytes() {return bytes; }
	public String print() { return("Constant Type: LONG\ntag: "+tag+"\nLong Value:"+bytes); }
	public String toString() { return("["+constIndex+"]"+bytes);	}
	public int getTag() { return tag; }
	public String getName() { return (""+bytes); }
}
