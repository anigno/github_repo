abstract public class GenericNode
{
	abstract public String toPrint();
}
