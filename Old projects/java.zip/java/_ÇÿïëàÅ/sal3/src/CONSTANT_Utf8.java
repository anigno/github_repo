import java.io.DataInputStream;
import java.io.IOException;

public class CONSTANT_Utf8 extends BasicClass
{
	private String stringUtf8;	//the "name" of the object
	private int length;
	
	CONSTANT_Utf8(DataInputStream input,int constantNum, boolean ToReserve) throws IOException	
	{
		if (ToReserve == true)
		{	
			tag = 1;
			stringUtf8 = new String("<RESERVED>");
			length = 0;
		}
		
		else
		{
			tag = 1;
			stringUtf8 = new String(input.readUTF());	
			length = stringUtf8.length();
			constIndex = constantNum;
			constantNum--;	

			for (; constantNum >= 0; constantNum-- )
			{
				if (GlobalVec.vec[constantNum].getTag() == tag)
				{	
					if ((((CONSTANT_Utf8)GlobalVec.vec[constantNum]).getName())
					.compareTo(stringUtf8) == 0)
						throw new IOException("Invalid Input");
				}			
			}
		}
	}
	
/*****/

    public String print()
    {
  	    return("Constant Type: UTF8\ntag: "+tag+"\nLength:"+length+"\nUTF8 String:"+stringUtf8);
    }	

	public String toString() { return("["+constIndex+"]"+stringUtf8); }
	public int getTag(){ return tag; }	
	public String getName() { return stringUtf8; }
}
