import java.io.DataInputStream;
import java.io.IOException;

//import org.apache.xpath.operations.Bool;

public class GlobalVec
{
	static private  BasicClass[] constVec;
	static public BasicClass[] vec; 
	static public int constPoolCnt;
	
/****/

	GlobalVec(DataInputStream input) throws IOException
	{
		int i,flag, tempTag;
		
		constPoolCnt = input.readShort();
		constVec =  new BasicClass[constPoolCnt];
		vec = constVec;
		constVec[0] = new CONSTANT_Utf8(input,0,true);
		
		for (i = 1; i < constPoolCnt; i++)
		{
			flag = InsertNewConstantPoolToVec(input,i);
			
			if (flag != 1)
				throw new IOException("Invalid Input");
		}		
	}

/*****/

	private static int InsertNewConstantPoolToVec(DataInputStream input, int constIndex) throws IOException
	{
		int tmpTag;	
		boolean isLegal;

		tmpTag = input.readByte();
		isLegal = true;

		try 
		{
			switch (tmpTag)
			{
				case (7):
				{	
					constVec[constIndex] = new CONSTANT_Class(input, constIndex);
					break;
				}
				
				case (9):
				{	
					constVec[constIndex] = new CONSTANT_Fieldref(input, constIndex);
					break;
				}
				
				case (10):
				{	
					constVec[constIndex] = new CONSTANT_Methodref(input, constIndex);
					break;
				}
				
				case (11):
				{	
					constVec[constIndex] = new CONSTANT_InterfaceMethodref(input, constIndex);
					break;
				}
				
				case (8):
				{	
					constVec[constIndex] = new CONSTANT_String(input, constIndex);
					break;
				}
				
				case (3):	
				{
					constVec[constIndex] = new CONSTANT_Integer(input, constIndex);
					break;
				}
				
				case (4):
				{	
					constVec[constIndex] = new CONSTANT_Float(input, constIndex);
					break;
				}
				
				case (5):
				{	
					constVec[constIndex] = new CONSTANT_Long(input, constIndex);
					break;
				}
				
				case (6):	
				{
					constVec[constIndex] = new CONSTANT_Double(input, constIndex);
					break;
				}
				
				case (12):
				{	
					constVec[constIndex] = new CONSTANT_NameAndType(input, constIndex);
					break;
				}
				
				case (1):
				{	
					constVec[constIndex] = new CONSTANT_Utf8(input,constIndex, false);
					break;
				}
				
				default:	// (-1)
					return -1;
			}
		}
		
		catch (IOException e)
		{
			return -1;
		}	
			
		return 1;		
	}

}