import java.io.DataInputStream;
import java.io.IOException;

public class Version extends BasicNode
{
	private short minor_version;	//2 bytes
	private short major_version;	//2 bytes
	
	/*
	 * Called after the magic number. 
	 * The fields of the minor and the major are updated.
	 */
/****/	
 
	Version(DataInputStream dataStream) throws IOException
	{
		minor_version=dataStream.readShort();
		major_version=dataStream.readShort();			
	}
			
	public String print() 
	{
		return ("minor_version: "+minor_version+"\nmajor_version: "+major_version);
	}
	
	public String toString()
	{
		return "version";
	}
}