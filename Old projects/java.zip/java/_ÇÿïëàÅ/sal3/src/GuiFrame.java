import java.awt.*;
import java.awt.event.*;


class GuiFrame extends Frame
{
	GuiFrame(String Title)
	{
		super(Title);
		addWindowListener(new WindowAdapter()
		 {
					public void windowClosing(WindowEvent e) 
					{
						dispose();
						System.exit(0);
					}
				});
	}
}