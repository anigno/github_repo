import java.io.DataInputStream;
import java.io.IOException;

public class CONSTANT_NameAndType extends BasicClass
{
	private short name_index;
	private short descriptor_index;
		
	CONSTANT_NameAndType(DataInputStream input,int constantNum) throws IOException
	{
		tag = 12;	
		constIndex = constantNum;	//Get index in the CP vector
		name_index = input.readShort();	//read next 2 bytes - for name_index
		descriptor_index = input.readShort();//read next 2 bytes - for descriptor_index
		
		constantNum--;	

		for (; constantNum >= 0; constantNum-- )
		  {
			  if (GlobalVec.vec[constantNum].getTag() == tag)
			  {	
				  if (((CONSTANT_NameAndType)GlobalVec.vec[constantNum]).getNameIndex() 
				  	== name_index) //same class found
				  {
					if (((CONSTANT_NameAndType)GlobalVec.vec[constantNum]).
						getDescriptorIndex() == descriptor_index)	//same name&type found
						throw new IOException("Invalid Input");//then error
				  }			  
			  }			
		  }		//end of while
		  
		  //Check legality of the FIELDREF structure
		if (GlobalVec.vec[name_index].getTag() != 1)	//UTF8 tag
			throw new IOException("Multiple Declaration");//then error
			
		if ((GlobalVec.vec[descriptor_index].getTag()!= 1))//UTF8 tag
			throw new IOException("Multiple Declaration");//then error
	}
	
/******/

	public String print()
	{
		return("Constant Type: NameAndType\ntag: "+tag+"\nName Index:"
		+name_index+"\nDescriptor Index: "+descriptor_index+"\nName String: "
		+(GlobalVec.vec[name_index]).getName()+"\nDescriptor String: "+
		(GlobalVec.vec[descriptor_index]).getName());
	}
 
	public String toString() { return("["+constIndex+"]"+getName()); }
	public short getNameIndex() { return name_index; }
	public short getDescriptorIndex() { return descriptor_index; }
	public int getTag() {return tag; }
	public String getName() { return (GlobalVec.vec[name_index]).getName(); 	}
}
