public class class_main {
    public static void main(String args[]){
        int array1[];
        array1=new int[12];   //all init to 0
        for(int a=0;a<12;a++){
            System.out.println(array1[a]);
        }//for

        int array2[]={1,2,3,4,5};   //init with values
        for(int a=0;a<5;a++){
            System.out.println(array2[a]);
        }//for

        //array size is fixed, no dynamic array!
        System.out.println("array1 length is: "+array1.length);
        //array2[5]=17;     java.lang.ArrayIndexOutOfBoundsException: 5

        //System.arraycopy (srcAry, srcPos,destAry,destPos,length)
        System.arraycopy(array2,0,array1,2,4);
        for(int a=0;a<12;a++){
            System.out.println(array1[a]);
        }//for


    }//main()
}//class_main
