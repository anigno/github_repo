public class class_primitiveVarTypes {
    byte b=3;                   //8 bit integer
    short a=-150;           //16 bit integer
    int i=757844;             //32 bit integer
    long l=367573477;     //64 bit integer
    float f;                    //32 bit floating point
    double d;                 //64 bit floating point
    boolean bool;      //true or false
    char c;                      //16 bit unicode character

    //in java Vars start with small letter
    //java does not have global Vars
}
