public class class_myString {
    String string;
    int length;

    class_myString(){
        string="";
        length=0;
    }//constructor()

    class_myString(String s){
        string=s;
        length=s.length();
    }//constructor(String)

    void print(){
        System.out.println(string);
    }//print()

    String add(String string){
        this.string=this.string+string;
        return this.string;
    }//add()

    String addNum(int i){
        this.string=this.string+i;
        return this.string;
    }//addNum()

    String getSub(int start,int end){
        return string.substring(start,end); 
    }//getSub()
}//class_myString
