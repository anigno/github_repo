public class class_main {
    public static void main(String args[]){
        class_myString a=new class_myString("anigno");
        class_myString b=new class_myString(" good morning ");
        a.add(b.string);
        a.print();
        a.addNum(768);
        a.print();
        b.string=a.getSub(3,9);
        b.print();
        double d=756348.25403;
        b.string=b.string+d;
        b.print();
    }//main()
}
