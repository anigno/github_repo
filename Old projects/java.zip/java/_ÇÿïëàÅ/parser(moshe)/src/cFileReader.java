import java.io.*;
public class cFileReader {
    private InputStream file=null;  //to read files
    private DataInputStream data;   //to read data types from stream
    public boolean EOF=false;   //EndOfFile flag

    public DataInput open(String fileName){
        try {
            file=new FileInputStream(fileName);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }//try catch
        data=new DataInputStream(file);
        return data;
    }//open()

    public void close(){
        try {
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }//try catch
    }//close()

    private byte getByte(){
        try {
            return data.readByte();
        } catch (IOException e) {
            if(e.getClass().equals(java.io.EOFException.class)){
                EOF=true;
            }//if
        }//catch
        return 0;
    }//getByte()

    public int getInt(){
        int result=0;
        byte a=getByte();
        if(EOF==false){
            //remove whitespace
            while( (a<'0')||(a>'9')){
                a=getByte();
            }//while
            result=a-48;    //'0' in 8 bit ascii is 48
            a=getByte();
            //read number
            while( (a>='0')&&(a<='9')){
                result=result*10+a-48;
                a=getByte();
            }//while
            return result;
        }//if
        return -1;
    }//getInt()

}//class cFileReader


