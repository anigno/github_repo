public class cJob {
    int number;
    int arrivalTime;
    int allocatedProcessors;
    int requestedRunTime;
    int actualRunTime;

    cJob(int n,int at,int ap,int rrt,int art){
        number=n;
        arrivalTime=at;
        allocatedProcessors=ap;
        requestedRunTime=rrt;
        actualRunTime=art;
    }//cJob
}//class cJob
