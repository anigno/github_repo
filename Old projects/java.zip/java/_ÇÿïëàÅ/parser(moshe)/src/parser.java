import java.util.LinkedList;

public class parser {
    private cFileReader reader=new cFileReader();
    public LinkedList jobs=new LinkedList();

    public static void main(String args[]){
        new parser(args[0]);
    }//main()

    parser(String fileName){
        reader.open(fileName);
        int i=reader.getInt();
        //if first integer is not -1 then another 4 integers exist
        while(i!=-1){
            cJob j=new cJob(i,reader.getInt(),reader.getInt(),reader.getInt(),reader.getInt());
            jobs.addLast(j);
            i=reader.getInt();
        }//if
        reader.close();
    }//parser()
}//class parser
