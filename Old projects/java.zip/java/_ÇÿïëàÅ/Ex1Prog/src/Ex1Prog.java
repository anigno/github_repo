public class Ex1Prog {
    public static void main(String args[]){
        for(int a=0;a<=args.length-1;a+=2){
            System.out.println(args[a]+" "+args[a+1]);
        }//for

    }//main
}
