public class cTree {
    cNode root=new cNode("");

    cTree(String rootData){
        root.data=rootData;
    }//cTree()

    cNode addNode(cNode parent,String data){
        cNode newNode=new cNode(data);
        parent.child[parent.childCnt]=newNode;
        parent.childCnt++;
        return newNode;
    }//addNode()

    void print(cNode root,int i){
        for(int j=0;j<i;j++)System.out.print("-");
        System.out.println(root.data);
        for(int a=0;a<root.childCnt;a++){
            print(root.child[a],i+2);
        }//for
    }//print()
}//cTree
