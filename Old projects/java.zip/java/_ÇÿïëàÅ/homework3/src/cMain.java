public class cMain {
    public static void main(String args[]){
        cTree myTree=new cTree("root");
        cNode c1=myTree.addNode(myTree.root,"child1");
        cNode c2=myTree.addNode(myTree.root,"child2");
        myTree.addNode(c1,"child11");
        myTree.addNode(c1,"child12");

        myTree.print(myTree.root,0);
    }//main()
}//cMain
