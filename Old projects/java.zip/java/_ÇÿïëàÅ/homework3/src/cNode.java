public class cNode {
    String data="";
    cNode[] child=new cNode[10];
    int childCnt;

    cNode(String data){
        this.data=data;
    }
}//cNode
