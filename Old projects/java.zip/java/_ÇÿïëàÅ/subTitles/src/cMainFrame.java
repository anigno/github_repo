import javax.swing.*;

public class cMainFrame extends JFrame{

    DefaultListModel model=new DefaultListModel();
    JList list=new JList(model);
    JScrollPane scrollPane=new JScrollPane(list);

    cMainFrame(){
        this.getContentPane().add(scrollPane);
        list.setVisible(true);
    }//cList()
    
}//class cMainFrame
