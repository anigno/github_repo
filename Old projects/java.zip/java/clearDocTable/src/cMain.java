
public class cMain {
    public static void main(String args[]){
        
        new cRunner(args[0]);
    }//main()
}//class cMain
