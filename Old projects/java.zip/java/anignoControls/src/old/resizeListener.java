package old;

public interface resizeListener {
    public void controlResized(String resizedSide,Object obj);
}
