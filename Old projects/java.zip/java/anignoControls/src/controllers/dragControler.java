package controllers;

public class dragControler {
    public static boolean isDrag=false;
}
