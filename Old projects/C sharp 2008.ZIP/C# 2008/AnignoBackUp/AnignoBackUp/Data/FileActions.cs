﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnignoBackUp.Data
{
    public static class FileActions
    {
        private static object _syncObject = new object();

    }
}
